////////////////////////////////////////
// NOME: BRUNO BARBOSA DE FREITAS     //
// MATRÍCULA: 12011BCC057             //
// NOME: JOÃO VITOR GONÇALVES OLIVEIRA//
// MATRICULA: 11921BCC024             //
////////////////////////////////////////

#include <stdio.h>
#include "TAD.h"

int main()
{
    FILE* arq;
    CEP* ceps;
    long cp;
    int op = 1;

    arq = fopen("cep ponto e virgula.txt", "r");
    if(arq == NULL){
        printf("ERRO! Arquivo (cep ponto e virgula.txt) nao encontrado!");
        return -1;
    }

    ceps = leArquivo(arq);

    ordenaCeps(ceps);

    while(op == 1){
        printf("Informe o cep que deseja buscar(somente numeros): ");
        scanf("%ld", &cp);

        if(buscaCep(ceps, cp) == -1)
            printf("CEP (%ld) nao encontrado!\n", cp);

        printf("Deseja procurar outro endereco? [digite 1]: ");
        scanf("%d", &op);
    }

    fclose(arq);

    printf("Encerrando buscas...\n");

    return 0;
}