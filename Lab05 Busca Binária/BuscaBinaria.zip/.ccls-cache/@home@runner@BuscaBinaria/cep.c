////////////////////////////////////////
// NOME: BRUNO BARBOSA DE FREITAS     //
// MATRÍCULA: 12011BCC057             //
// NOME: JOÃO VITOR GONÇALVES OLIVEIRA//
// MATRICULA: 11921BCC024             //
////////////////////////////////////////

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "TAD.h"

void quicksort_basico(CEP* vetor, long, long);
void troca(CEP*, long, long);
long particao(CEP*, long, long);
long buscaBinaria(CEP*, long, long, long);

struct cep{
    long cep;
    char uf[3];
    char cidade[39];        // 38(maior num. de carac. de cidade)
    char endereco[68];      // 67(maior num. de carac. de endereço)
};

//  FUNÇÕES DO TAD
CEP* leArquivo(FILE* arq){
    long cont_linha = 1;
    int cont_col = 1;
    int maiorLinha = 0;
    char c;

    do{
        c = fgetc(arq);
        if(c == '\n'){
            cont_linha++;

            if(cont_col > maiorLinha)
                maiorLinha = cont_col;

            cont_col = 1;
        }
        else
            cont_col++;
    }
    while(c != EOF);

    CEP* ceps = (CEP*) malloc((cont_linha*sizeof(CEP))+1);
    if(ceps == NULL)
        return NULL;

    long i;
    for(i = 0; i < cont_linha+1; i++){
        ceps[i] = (CEP) malloc(sizeof(struct cep));
        if(ceps[i] == NULL)
            return NULL;
    }
    ceps[0]->cep = cont_linha-1;  // campo "cep" inicial guarda o num de ceps registrados

    rewind(arq);

    char linha[maiorLinha];
    for(i = 1; fgets(linha, maiorLinha+2, arq) != NULL; i++){
        ceps[i]->cep = (1000*atoi(strtok(linha, "-"))) + atoi(strtok(NULL, ";"));
        strcpy(ceps[i]->uf, strtok(NULL, ";"));
        strcpy(ceps[i]->cidade, strtok(NULL, ";"));
        strcpy(ceps[i]->endereco, strtok(NULL, ";"));
    }

    return ceps;
}

int ordenaCeps(CEP* vetor){
    if(vetor == NULL)
        return 0;

    long esq = 1;
    long dir = vetor[0]->cep;

    if (esq >= dir)
        return 0;

    troca(vetor, (esq+dir)/2, esq+1);

    if(vetor[esq]->cep > vetor[esq+1]->cep)
        troca(vetor, esq, esq+1);
    if(vetor[esq]->cep > vetor[dir]->cep)
        troca(vetor, esq, dir);
    if(vetor[esq+1]->cep > vetor[dir]->cep)
        troca(vetor, esq+1, dir);

    long pivo = particao(vetor, esq+1, dir-1);

    quicksort_basico(vetor, esq, pivo-1);
    quicksort_basico(vetor, pivo+1, dir);

    return 1;
}

void imprimeCeps(CEP* ceps){
    long i;
    for(i = 1; i < ceps[0]->cep; i++){
        if(ceps[i]->cep < 10000000)
            printf("0");

        printf("%ld\t%s\t%s\t%s", ceps[i]->cep, ceps[i]->uf, ceps[i]->cidade, ceps[i]->endereco);
    }
}

int buscaCep(CEP* ceps, long cep){
    long pos_cep = buscaBinaria(ceps, 1, ceps[0]->cep, cep);
    if(pos_cep == -1)
        return -1;

    printf("\n------ ENDERECO ------\n");
    if(ceps[pos_cep]->cep < 10000000) putchar('0');
    printf("CEP: %ld\n"
           "UF: %s\n"
           "CIDADE: %s\n"
           "ENDERECO: %s\n",
           ceps[pos_cep]->cep, ceps[pos_cep]->uf, ceps[pos_cep]->cidade, ceps[pos_cep]->endereco);

    return 1;
}

//  FUNÇÕES PARA ORDENAÇÃO E BUSCA
void quicksort_basico(CEP* vetor, long esq, long dir) {
  if (esq >= dir)
    return;

  long pivo = particao(vetor, esq, dir);

  quicksort_basico(vetor, esq, pivo-1);
  quicksort_basico(vetor, pivo+1, dir);
}

long particao(CEP* vetor, long esq, long dir) {
  long i, pivo;

  pivo = esq;
  for (i = esq + 1; i <= dir; i++) {
    if (vetor[i]->cep < vetor[esq]->cep) {
      pivo++;
      troca(vetor, pivo, i);
    }
  }
  troca(vetor, esq, pivo);

  return pivo;
}

void troca(CEP* vetor, long p1, long p2){
    CEP aux;
    aux = vetor[p1];
    vetor[p1] = vetor[p2];
    vetor[p2] = aux;
}

long buscaBinaria(CEP* ceps, long inf, long sup, long cep){
    if(sup < inf)
        return -1;

    long meio = (inf + sup)/2;

    if(ceps[meio]->cep == cep)
        return meio;
    else if(ceps[meio]->cep > cep)
        return buscaBinaria(ceps, inf, meio-1, cep);
    else
        return buscaBinaria(ceps, meio+1, sup, cep);
}