////////////////////////////////////////
// NOME: BRUNO BARBOSA DE FREITAS     //
// MATRÍCULA: 12011BCC057             //
// NOME: JOÃO VITOR GONÇALVES OLIVEIRA//
// MATRICULA: 11921BCC024             //
////////////////////////////////////////

#ifndef TAD_H_INCLUDED
#define TAD_H_INCLUDED

typedef struct cep* CEP;

CEP* leArquivo(FILE*);
int ordenaCeps(CEP*);
int buscaCep(CEP*, long);
void imprimeCeps(CEP*);

#endif // TAD_H_INCLUDED